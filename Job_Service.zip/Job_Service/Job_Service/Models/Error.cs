﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Job_Service.Models
{
    public class Error
    {
            public string ErrorMessage { get; set; }
          
    }
}
