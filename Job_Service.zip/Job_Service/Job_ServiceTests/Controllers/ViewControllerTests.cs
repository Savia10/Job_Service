﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework.Internal;
using Job_Service.Controllers;
using System;
using System.Collections.Generic;
using System.Text;

namespace Job_Service.Controllers.Tests
{
    [TestClass()]
    public class ViewControllerTests
    {
        [TestMethod()]
        public void ViewControllerTest()
        {

        }

        [TestMethod()]
        public void GetTest()
        {

        }

        [TestMethod()]
        public void GetDepartmentsTest()
        {

        }

        [TestMethod()]
        public void GetLocationsTest()
        {

        }

        [TestMethod()]
        public void CreateEmployeeTest()
        {

        }

        [TestMethod()]
        public void UpdateEmployeeTest()
        {

        }

        [TestMethod()]
        public void ViewControllerTest1()
        {
            throw new NotImplementedException();
        }

        [TestMethod()]
        public void GetTest1()
        {
            throw new NotImplementedException();
        }

        [TestMethod()]
        public void GetDepartmentsTest1()
        {
            throw new NotImplementedException();
        }

        [TestMethod()]
        public void GetLocationsTest1()
        {
            throw new NotImplementedException();
        }

        [TestMethod()]
        public void CreateEmployeeTest1()
        {
            throw new NotImplementedException();
        }

        [TestMethod()]
        public void UpdateEmployeeTest1()
        {
            throw new NotImplementedException();
        }

        [TestMethod()]
        public void ViewControllerTest2()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void GetTest2()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void GetDepartmentsTest2()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void GetLocationsTest2()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void CreateEmployeeTest2()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void UpdateEmployeeTest2()
        {
            Assert.Fail();
        }
    }
}